<?php $__env->startSection('content'); ?>
        <h2>Categories</h2><hr>
        <div class="row">
            <div class="col-md-2">
                Name
            </div>
            <div class="col-md-2">
                Delete
            </div><br>
            <div class="col-md-2">
                Edit
            </div>
        </div><hr style="border-style: inset; border-width: 3px;">
        <?php if($categories->count() > 0): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-md-2">
                        <?php echo e($category->name); ?>

                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('category.delete', ['id' => $category->id])); ?>" class="btn btn-danger">
                            <span><i class="fas fa-trash-alt"></i></span>
                        </a>
                    </div><br>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('category.edit', ['id' => $category->id])); ?>" class="btn btn-info">
                            <span><i class="fas fa-pencil-alt"></i></span>
                        </a>
                    </div>
                </div><hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <span>No Categories created</span>
            <?php endif; ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>